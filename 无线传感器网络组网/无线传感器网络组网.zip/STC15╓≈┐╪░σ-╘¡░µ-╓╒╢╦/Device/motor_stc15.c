/************************************************************************/
/*********                      motor_stc15.C                       *************/
/**********          Written By ZQW---20160831              *************/
/**********                  Version 1.92			      ***************/
/************************************************************************/
#include "STC15.H"
#include "DataForm_STC15.H"
#include "motor_stc15.h"

//-----------------------------------------------------------------------
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//-----------------------------------------------------------------------
//----------------------����˵��-----------------------------------------
/*																	   */
//-----------------------------------------------------------------------
//=======================================================================

//-----------------------------------------------------------------------
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//-----------------------------------------------------------------------
//----------------------���ݱ�������-------------------------------------
//-----------------------------------------------------------------------
//=======================================================================
//��ת-------------------------------------------------
uint8 A1States[8] = { 0, 0, 0, 1, 1, 1, 0, 0 };		//������� 8�� 12345678
uint8 A2States[8] = { 1, 1, 0, 0, 0, 0, 0, 1 };		//������� 4�� 1357
uint8 B1States[8] = { 0, 1, 1, 1, 0, 0, 0, 0 };
uint8 B2States[8] = { 0, 0, 0, 0, 0, 1, 1, 1 };

uint8 A1States1[8] = { 0, 0, 1, 1, 0 };		//������� 8�� 12345678
uint8 A2States1[8] = { 1, 0, 0, 0, 1 };		//������� 4�� 1357
uint8 B1States1[8] = { 0, 1, 0, 0, 0 };
uint8 B2States1[8] = { 0, 0, 0, 1, 1 };
//��ת---------------------------------------------------

uint8 C1States[8] = {0,0,1,1,1,0,0,0};
uint8 C2States[8] = {1,0,0,0,0,0,1,1};
uint8 D1States[8] = {0,0,0,0,1,1,1,0};
uint8 D2States[8] = {1,1,1,0,0,0,0,0};

uint8 C1States1[8] = {0,1,1,0};
uint8 C2States1[8] = {1,0,0,1};
uint8 D1States1[8] = {0,0,1,1};
uint8 D2States1[8] = {1,1,0,0};

int16 motor_recent2 = 0;
int16 motor_recent1 = 0;

uint16 Timer_motor = 0;
uint8 Flag_motor = 1;
uint8 MOT = 0;

uint8 currentstatea = 0;
uint8 currentstateb = 0;
uint16 Stepa = 0;
uint16 Stepb = 0; 
fp32 Hudu = 0;
//-----------------------------------------------------------------------
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//-----------------------------------------------------------------------
//----------------------���庯��ʵ��-------------------------------------
//-----------------------------------------------------------------------
//=======================================================================
void Timer2Init(void)		//1����@11.0592MHz
{
	AUXR |= 0x04;		//��ʱ��ʱ��1Tģʽ
	T2L = 0xCD;		//���ö�ʱ��ֵ
	T2H = 0xD4;		//���ö�ʱ��ֵ
	AUXR |= 0x10;		//��ʱ��2��ʼ��ʱ
	EA = 1;
}



void Enable_Timer2_INT(void)		//��ʱ��2���ж�
{	
	IE2|=0x04;
}

void Disable_Timer2_INT(void)		//��ʱ��2���ж�
{	
	IE2&=0xfb;
}

void Delay18ms()		//@11.0592MHz
{
	unsigned char i, j, k;

	i = 1;
	j = 194;
	k = 160;
	do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
}



//�������---------------------------
void motor1_gpio()
{
	P1M0 &= ~0X0f;
	P1M1 &= ~0X0f;
}

void motor2_gpio()
{
	P1M0 &= ~0Xf0;
	P1M1 &= ~0Xf0;
}

void motor3_gpio()
{
	P2M0 &= ~0X0f;
	P2M1 &= ~0X0f;
}

void motor4_gpio()
{
	P4M0 &= ~0X36;
	P4M1 &= ~0X36;
}

void yuan_0_90()
{
	motor_recent2 = -motor_recent2;
	while(motor_recent1!=0 || motor_recent2!=0)
	{
		if(motor_recent2!=0)
		{
			B_run_1();
			motor_recent2--;
		}
		if(motor_recent1!=0)
		{
			A_run_1();
			motor_recent1--;
		}
	}							
}

void yuan_90_180()
{
	motor_recent1 = -motor_recent1;
	motor_recent2 = -motor_recent2;
	while(motor_recent1!=0 || motor_recent2!=0)
	{
		if(motor_recent2!=0)
		{
			B_run_1();
			motor_recent2--;
		}
		if(motor_recent1!=0)
		{
			A_run_2();
			motor_recent1--;
		}
	}							
}

void yuan_180_270()
{
	motor_recent1 = -motor_recent1;
	while(motor_recent1!=0 || motor_recent2!=0)
	{
		if(motor_recent2!=0)
		{
			B_run_2();
			motor_recent2--;
		}
		if(motor_recent1!=0)
		{
			A_run_2();
			motor_recent1--;
		}
	}							
}

void yuan_270_360()
{
	while(motor_recent1!=0 || motor_recent2!=0)
	{
		if(motor_recent2!=0)
		{
			B_run_2();
			motor_recent2--;
		}
		if(motor_recent1!=0)
		{
			A_run_1();
			motor_recent1--;
		}
	}							
}





void A_run_1()
{
	motora_a1= C1States[currentstatea];
	motora_a2= C2States[currentstatea];
	motora_b1= D1States[currentstatea];
	motora_b2= D2States[currentstatea];

	motorc_a1= A1States[currentstatea];
	motorc_a2= A2States[currentstatea];
	motorc_b1= B1States[currentstatea];
	motorc_b2= B2States[currentstatea];
	currentstatea++;
	if(currentstatea>7) currentstatea = 0;
	Delay18ms();
}

void A_run_2()	 //x��Ƕ���
{
	motora_a1= A1States[currentstatea];
	motora_a2= A2States[currentstatea];
	motora_b1= B1States[currentstatea];
	motora_b2= B2States[currentstatea];

	motorc_a1= C1States[currentstatea];
	motorc_a2= C2States[currentstatea];
	motorc_b1= D1States[currentstatea];
	motorc_b2= D2States[currentstatea];
	currentstatea++;
	if(currentstatea>7) currentstatea = 0;
	Delay18ms();
}

void B_run_1()
{
	motorb_a1= C1States[currentstateb];
	motorb_a2= C2States[currentstateb];
	motorb_b1= D1States[currentstateb];
	motorb_b2= D2States[currentstateb];

	motord_a1= A1States[currentstateb];
	motord_a2= A2States[currentstateb];
	motord_b1= B1States[currentstateb];
	motord_b2= B2States[currentstateb];
	currentstateb++;
	if(currentstateb>7) currentstateb = 0;
	Delay18ms();
}

void B_run_2()
{
	motord_a1= C1States[currentstateb];
	motord_a2= C2States[currentstateb];
	motord_b1= D1States[currentstateb];
	motord_b2= D2States[currentstateb];

	motorb_a1= A1States[currentstateb];
	motorb_a2= A2States[currentstateb];
	motorb_b1= B1States[currentstateb];
	motorb_b2= B2States[currentstateb];
	currentstateb++;
	if(currentstateb>7) currentstateb = 0;
	Delay18ms();
}

//------------------------------------------------------------------------------------

void run_0_90()
{
	while(Stepa!=0 || Stepb!=0)
	{
		if(Stepa!=0)
		{
			A_run_1();
			Stepa--;
		}
		if(Stepb!=0)
		{
			B_run_1();
			Stepb--;
		}	
	}
	Stepa=10;
	Stepb=0;
}

void run_90_180()
{
	while(Stepa!=0 || Stepb!=0)
	{
		if(Stepa!=0)
		{
			B_run_1();
			Stepa--;
		}
		if(Stepb!=0)
		{
			A_run_2();
			Stepb--;
		}	
	}
	Stepa=10;
	Stepb=0;
}

void run_180_270()
{
	while(Stepa!=0 || Stepb!=0)
	{
		if(Stepa!=0)
		{
			A_run_2();
			Stepa--;
		}
		if(Stepb!=0)
		{
			B_run_2();
			Stepb--;
		}	
	}
	Stepa=10;
	Stepb=0;
}

void run_270_360()
{
	while(Stepa!=0 || Stepb!=0)
	{
		if(Stepa!=0)
		{
			B_run_2();
			Stepa--;
		}
		if(Stepb!=0)
		{
			A_run_1();
			Stepb--;
		}	
	}
	Stepa=10;
	Stepb=0;
}
//----------------------------------------------------------------------------------------
//------------------------------
//------------------------------
//--------------------------------------------------------------------------
//------------------------------
//------------------------------
//--------------------------------------------------------------------------
void Run_toger_up()
{
	for(MOT=0;MOT<=7;MOT++)
	{
		motora_a1= C1States[MOT];
		motora_a2= C2States[MOT];
		motora_b1= D1States[MOT];
		motora_b2= D2States[MOT];
		
		motorb_a1= C1States[MOT];
		motorb_a2= C2States[MOT];
		motorb_b1= D1States[MOT];
		motorb_b2= D2States[MOT];

		motorc_a1= C1States[MOT];
		motorc_a2= C2States[MOT];
		motorc_b1= D1States[MOT];
		motorc_b2= D2States[MOT];
		
		motord_a1= C1States[MOT];
		motord_a2= C2States[MOT];
		motord_b1= D1States[MOT];
		motord_b2= D2States[MOT];
	
		Delay18ms();
	}
}

void Run_toger_dowm()
{
	for(MOT=0;MOT<=7;MOT++)
	{
		motora_a1= A1States[MOT];
		motora_a2= A2States[MOT];
		motora_b1= B1States[MOT];
		motora_b2= B2States[MOT];
		
		motorb_a1= A1States[MOT];
		motorb_a2= A2States[MOT];
		motorb_b1= B1States[MOT];
		motorb_b2= B2States[MOT];

		motorc_a1= A1States[MOT];
		motorc_a2= A2States[MOT];
		motorc_b1= B1States[MOT];
		motorc_b2= B2States[MOT];
		
		motord_a1= A1States[MOT];
		motord_a2= A2States[MOT];
		motord_b1= B1States[MOT];
		motord_b2= B2States[MOT];
	
		Delay18ms();
	}
}

void Stop_toger()
{
	motora_a1 = 0; 
	motora_a2 = 0;
	motora_b1 = 0;
	motora_b2 = 0;
	
	motorb_a1 = 0;
	motorb_a2 = 0;
	motorb_b1 = 0;
	motorb_b2 = 0;
	
	motorc_a1 = 0;
	motorc_a2 = 0;
	motorc_b1 = 0;
	motorc_b2 = 0;
	
	motord_a1 = 0;
	motord_a2 = 0;
	motord_b1 = 0;
	motord_b2 = 0;
}


//------------------------------
//------------------------------
//--------------------------------------------------------------------------
//------------------------------
//------------------------------
//--------------------------------------------------------------------------
void Run_x1()	 //x��Ƕȸ�
{
	for(MOT=0;MOT<=7;MOT++)
	{
		motora_a1= C1States[MOT];
		motora_a2= C2States[MOT];
		motora_b1= D1States[MOT];
		motora_b2= D2States[MOT];

		motorc_a1= A1States[MOT];
		motorc_a2=	A2States[MOT];
		motorc_b1=	B1States[MOT];
		motorc_b2= B2States[MOT];
		Delay18ms();
	}
}

void Run_x2()	 //x��Ƕ���
{
	for(MOT=0;MOT<=7;MOT++)
	{
		motora_a1= A1States[MOT];
		motora_a2=  A2States[MOT];
		motora_b1=	B1States[MOT];
		motora_b2= B2States[MOT];

		motorc_a1= C1States[MOT];
		motorc_a2=	C2States[MOT];
		motorc_b1=	D1States[MOT];
		motorc_b2= D2States[MOT];
		Delay18ms();
	}
}

void Run_y1()	 //y��Ƕȸ�
{
	for(MOT=0;MOT<=7;MOT++)
	{
		motorb_a1= C1States[MOT];
		motorb_a2=	C2States[MOT];
		motorb_b1=	D1States[MOT];
		motorb_b2= D2States[MOT];

		motord_a1= A1States[MOT];
		motord_a2=	A2States[MOT];
		motord_b1=	B1States[MOT];
		motord_b2= B2States[MOT];
		Delay18ms();
	}
}

void Run_y2()	 //y��Ƕ���
{
	for(MOT=0;MOT<=7;MOT++)
	{
		motorb_a1= A1States[MOT];
		motorb_a2=	A2States[MOT];
		motorb_b1=	B1States[MOT];
		motorb_b2= B2States[MOT];

		motord_a1= C1States[MOT];
		motord_a2=	C2States[MOT];
		motord_b1=	D1States[MOT];
		motord_b2= D2States[MOT];
		Delay18ms();
	}
}

//=======================================================================
//--------------------------End of motor_stc15.C---------------------------------
//=======================================================================
