/************************************************************************/
/*********                      New.C                       *************/
/**********          Written By ZQW---20130117              *************/
/**********                  Version 1.0			      ***************/
/************************************************************************/
#include "STC15.H"
#include "DataForm_STC15.H"
#include "KEY.H"

//-----------------------------------------------------------------------
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//-----------------------------------------------------------------------
//----------------------���ݱ�������-------------------------------------
//-----------------------------------------------------------------------
//=======================================================================
uint8 Key_Value = 0;

//-----------------------------------------------------------------------
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//-----------------------------------------------------------------------
//----------------------���庯��ʵ��-------------------------------------
//-----------------------------------------------------------------------
//=======================================================================



void Init_GPIO_KEY(void)
{
	//------IO�ڳ�ʼ��------
	P3M0&=~0xCC;	//KEY����Ϊ׼˫���
	P3M1&=~0xCC;
}

//-------------------------------------------
//��ʱ����
void Delay(uint16 t)		//Լ500ms@t=22\�Ƚ�׼ȷ
{
	uint8 j=3,k=227;

	do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--t);
}
//-------------------------------------------

//-------------------------------------------
//��ȡ����1
uint8 Read_KEY1(void)
{
	KEY1=1;
	
	if(KEY1==0)
	{
		Delay(1);
		if(KEY1==0)
		{
			while(!KEY1);
			return TRUE;
		}
		else return FALSE;
	}
	else return FALSE;
}
//-------------------------------------------
//��ȡ����1ֱ������
uint8 Read_KEY1_Release(void)
{
	KEY1=1;
	
	if(KEY1==0)
	{
		Delay(1);
		if(KEY1==0)
		{
			while(KEY1==0);
			return TRUE;
		}
		else return FALSE;
	}
	else return FALSE;
}
//-------------------------------------------
//��ȡ����2
uint8 Read_KEY2(void)
{
	KEY2=1;
	
	if(KEY2==0)
	{
		Delay(1);
		if(KEY2==0)
		{
			return TRUE;
		}
		else return FALSE;
	}
	else return FALSE;
}
//-------------------------------------------
//��ȡ����2ֱ������
uint8 Read_KEY2_Release(void)
{
	KEY2=1;
	
	if(KEY2==0)
	{
		Delay(1);
		if(KEY2==0)
		{
			while(KEY2==0);
			return TRUE;
		}
		else return FALSE;
	}
	else return FALSE;
}

//-------------------------------------------
//��ȡ����3
uint8 Read_KEY3(void)
{
	KEY3=1;
	
	if(KEY3==0)
	{
		Delay(1);
		if(KEY3==0)
		{
			return TRUE;
		}
		else return FALSE;
	}
	else return FALSE;
}

//-------------------------------------------
//��ȡ����4
uint8 Read_KEY4(void)
{
	KEY4=1;
	
	if(KEY4==0)
	{
		Delay(1);
		if(KEY4==0)
		{
			while(!KEY4);
			return TRUE;
		}
		else return FALSE;
	}
	else return FALSE;
}

uint8 KEY_RETURN(void)
{
	 if(Read_KEY1_Release()) Key_Value = 1;
	 if(Read_KEY2_Release()) Key_Value = 2;
	 if(Read_KEY3()) Key_Value = 3;
	 if(Read_KEY4()) Key_Value = 4;
	 return(Key_Value);
}


//	while(1)
//	{
//		WriteCommandLCM(0x80+0x40, 1);
//		DisplayListChar(0, 1, "Angle", 5);
//		SeriPushSend(0XA5); 
//        SeriPushSend(0X51);                                        //����1֡��ȡ���������ȡ 
//		Display();											
//		lcd_printf(dis, YPR[2]/100);			//ת��������ʾ
//		DisplayListChar(6, 1, dis, 4);
//	
//		if(Read_KEY1())										//����ģʽ
//		{	
//			DisplayListChar(0, 0, "set mode", 8);
//			while(model)
//			{
//				if(Read_KEY1())	 key_count1++;
//				if(key_count1>2) key_count1=1;
//				Delay(1);
//				lcd_printf(dis, key_count1);
//				DisplayListChar(9, 0, dis, 4);
//				if(Read_KEY4())	 model=0;
//			}
//			model=1;
//
//
//		Delay(22);
//		if(key_count1==1)
//		{
//			WriteCommandLCM(0x01, 1);
//			DisplayListChar(0, 0, "set:", 4);
//			while(angle1)
//			{
//				if(Read_KEY2()) key_count2++;
//				if(Read_KEY3()) key_count2--;
//				Delay(3);
//				lcd_printf(dis, key_count2);
//				DisplayListChar(5, 0, dis, 4);
//				if(Read_KEY4())	 angle1=0;
//			}
//			angle1=1;	
//			Delay(6);
//		
//			while(out_1)
//			{
//				WriteCommandLCM(0x80+0x40, 1);
//				DisplayListChar(0, 1, "Angle", 5);
//				SeriPushSend(0XA5); 
//		        SeriPushSend(0X51);                                        //����1֡��ȡ���������ȡ 
//				Display();											
//				lcd_printf(dis, YPR[2]/100);			//ת��������ʾ
//				DisplayListChar(6, 1, dis, 4);	
//				if(90<key_count2<=95) PID_CONTROL_9590(key_count2,YPR[2]/100);
//			}	  		 	
//		}
//		}
//	}







	
//	while(1)
//	{
//		
//		if(Read_KEY1())										//����ģʽ
//		{	
//			WriteCommandLCM(0x01, 1);			  //��ʾ����
//			DisplayListChar(0, 0, "set mode", 8);
//			while(model)
//			{
//				if(Read_KEY1())	 key_count1++;
//				if(key_count1>2) key_count1=1;
//				Delay(6);
//				lcd_printf(dis, key_count1);
//				DisplayListChar(9, 0, dis, 4);
//				if(Read_KEY4())	 model=0;
//			}
//			model=1;
//
//
//		Delay(22);
//		if(key_count1==1)
//		{
//			WriteCommandLCM(0x01, 1);
//			DisplayListChar(0, 0, "set:", 4);
//			while(angle1)
//			{
//				if(Read_KEY2()) key_count2++;
//				if(Read_KEY3()) key_count2--;
//				Delay(3);
//				lcd_printf(dis, key_count2);
//				DisplayListChar(5, 0, dis, 4);
//				if(Read_KEY4())	 angle1=0;
//			}
//			angle1=1;	
//
//
//		Delay(22);
//		if(key_count1==2)
//		{
//			WriteCommandLCM(0x01, 1);
//			DisplayListChar(0, 0, "set:", 4);
//			while(angle2)
//			{
//				while(angle2_1)
//				{
//					if(Read_KEY2()) key_count2++;
//					if(Read_KEY3()) key_count2--;
//					Delay(3);
//					lcd_printf(dis, key_count2);
//					DisplayListChar(5, 0, dis, 4);
//					if(Read_KEY4())	 angle2_1=0;
//				}
//				Delay(6);
//				if(Read_KEY2()) key_count3++;
//				if(Read_KEY3()) key_count3--;
//				lcd_printf(dis, key_count3);
//				DisplayListChar(10, 0, dis, 4);
//				if(Read_KEY4())	 angle2=0;
//			}
//			angle2_1=1;
//			angle2=1;
//		}
//		}
//	}
//=======================================================================
//--------------------------End of KEY.C---------------------------------
//=======================================================================
