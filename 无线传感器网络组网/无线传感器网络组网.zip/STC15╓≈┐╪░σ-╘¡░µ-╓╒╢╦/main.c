/************************************************************************/
/*********                     main.C                       *************/
/**********          Written By ZQW---20160715              *************/
/**********                  Version 1.0			      ***************/
/************************************************************************/
#include "Cfg_STC15.H"
#define	LED1 P55
void main()
{
	uint16 cout = 0;
	Init_HC595(); //��ʼ��˳���ܵ���
	InitGPIO_lcd();
	InitLcd();	
	init_uart1();
	Uart2Init();
	En_Uart2();
	DisplayListChar(0, 0, "loading...", 10);
	Delay(20);
	WriteCommandLCM(0x01);
	while(1)
	{	
		  if(BUF[4] == 0x2a) 
			{
					WENDU[0] = (BUF[6] << 8) + BUF[7];					
					Display10BitData(WENDU[0], 0, 0);
			}
			else if(BUF[4] == 0x4F) 
			{
				  WENDU[1] = (BUF[6] << 8) + BUF[7];
				  Display10BitData(WENDU[1], 5, 0);
			}
			else if(BUF[4] == 0x17) 
			{
				  WENDU[2] = (BUF[6] << 8) + BUF[7];
				  Display10BitData(WENDU[2], 10, 0);
			}
			else if(BUF[4] == 0xAE) 
			{
				  WENDU[3] = (BUF[6] << 8) + BUF[7];
				  Display10BitData(WENDU[3], 0, 1);
			}
			else if(BUF[4] == 0xDE) 
			{
				  WENDU[4] = (BUF[6] << 8) + BUF[7];
				  Display10BitData(WENDU[4], 5, 1);
			}
			
			trans_string();
			
			if(cout>=200)
			{
				SendString2(Buffer_1);	
				cout=0;				
			}
			cout++;
	}
}



//=======================================================================
//--------------------------End of main.C--------------------------------
//=======================================================================
