/************************************************************************/
/*********                     main.C                       *************/
/**********          Written By ZQW---20160715              *************/
/**********                  Version 1.0			      ***************/
/************************************************************************/
#include "Cfg_STC15.H"

#define	LED1 P55

uint16 Value = 0;
//uint8 Buffer[30]=0;
uint16 temp_use = 0;


void main()
{
//	Init_HC595(); //��ʼ��˳���ܵ���
//	InitGPIO_lcd();
//	InitLcd();	
	init_uart1();
//	DisplayListChar(0, 0, "Loading...", 10);
//	Delay(10);
//	WriteCommandLCM(0x01);
	while(1)
	{	
		Value = (uint16)(Read_Temperature()*10);
		DL_LN33_BUF[7] = Value;
		DL_LN33_BUF[6] = (Value >> 8);
		send_buf();
		Delay(15);
	}
}

//		sprintf(Buffer,"Temp=%04.1f C",Value);
//		DisplayListChar(0, 0, Buffer, 11);

//=======================================================================
//--------------------------End of main.C--------------------------------
//=======================================================================
